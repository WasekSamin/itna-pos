window.onload = function() {
    document.querySelector("body").style.overflow = "hidden";
}