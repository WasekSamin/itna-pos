const restaurantPrintBtn = document.querySelector(".restaurant__printBtn");

restaurantPrintBtn.addEventListener("click", () => {
    window.print();
});